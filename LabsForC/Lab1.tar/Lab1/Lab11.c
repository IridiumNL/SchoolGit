/********************************
********* RANDY PARSONS *********
*********   20133932    *********
*********    CT2530	*********
********************************/

// This code prints text to the terminal window using the printf function

#include <stdio.h>

int main(int argc, char **argv) {
	printf("Hello, C\n");
	return 0;
}
